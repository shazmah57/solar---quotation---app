# Solar Quote Calculator: Developer Handover & Technical Specification

This document provides the technical requirements and UI specifications for the "Sustainable Solar Energy Solutions" internal sales tool, based on the high-fidelity design {{DATA:SCREEN:SCREEN_2}}.

## 1. Project Overview
- **Brand Name:** Sustainable Solar Energy Solutions
- **App Type:** Internal Sales Tool (Mobile)
- **Primary Objective:** Real-time quotation generation with editable pricing overrides and PDF export.

## 2. Design System (Solar Utility System)
- **Primary Color:** `#0f172a` (Deep Slate)
- **Accent Color:** `#facc15` (Solar Yellow - for branding and status)
- **Typography:** Hanken Grotesk (Sans-serif)
- **Surface Colors:** Soft blues and whites (`#f8f9ff`, `#eff4ff`) to reduce glare during field use.
- **Roundness:** `ROUND_FOUR` (4px to 8px radius) for a modern, utility-focused feel.

## 3. UI Component Specifications

### A. Client Information (Manual Inputs)
| Field | Type | Validation/Input Type |
| :--- | :--- | :--- |
| Quoted To | Text | Full Name |
| Contact No. | Tel | Phone formatting (e.g., +92 XXX XXXXXXX) |
| Email Address | Email | standard email regex |
| Quotation Number | Text | Default: `SSES-YYYY-XXX` |
| Issue/Expiry Date | Date | Date Picker |

### B. Dynamic Hardware Pickers (Items 1-4)
Each item is a card containing:
1. **Model Selection:** Dropdown/Searchable picker.
2. **Quantity:** Numeric input (Editable).
3. **Unit Price (PKR):** Numeric input (Editable - Default values based on model selection, but allow manual override).
4. **Line Total:** Calculated field (ReadOnly): `Quantity * Unit Price`.

**Hardware Catalog Reference:**
- **Panels:** Longi Himo x10, Trina/Jinko Bifacial, Aiko Bifacial.
- **Inverters:** Solax, Goodwe, Solis, Inverex Nitrox, Itel (4kW to 20kW).
- **Batteries:** Solax/Fronus/Invt/Sunwoda/Pylontech/Soluna (5kWh to 16kWh, IP21/IP65).
- **Mounting:** Elevated, Ground Mount, Semi Elevated. *Note: Selecting mounting type should inject technical description text.*

### C. Fixed Logistics (Items 5-6)
- **Balance of System:** Fixed description. Quantity: "Estimated". Price: Editable PKR.
- **Installation & Transportation:** Fixed description. Quantity: "1 Job". Price: Editable PKR.

## 4. Business Logic (Real-time)
- **Line Total Calculation:** `LineTotal = qty * unit_price`
- **Grand Total Calculation:** `GrandTotal = sum(LineTotals[1...6])`
- **Currency Formatting:** Display all PKR values with comma separators (e.g., `1,560,000.00`).

## 5. Assets
- **Logo:** {{DATA:IMAGE:IMAGE_4}}
- **Icons:** Material Design Icons (solar_power, calculate, description, settings).

## 6. PDF Generation Requirements
- **Header:** Brand Logo + Company Name.
- **Grid:** 6-column pricing table.
- **Footer:** Warranty and Terms & Conditions clauses as specified in the PRD.
